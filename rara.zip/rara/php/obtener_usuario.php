<?php
header("Content-Type: application/json");
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $cedula = $_GET["cedula"] ?? '';

    if (!$cedula) {
        echo json_encode(["error" => "Cédula no proporcionada"]);
        exit;
    }

    $sql = "SELECT nombre FROM usuarios WHERE cedula = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $cedula);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode(["nombre" => $row["nombre"]]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Usuario no encontrado"]);
    }

    $stmt->close();
}

$conn->close();
?>
