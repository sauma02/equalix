<?php
$host = "srv1069.hstgr.io";
$user = "u949606062_equifax";
$pass = "Supergamo123@";
$dbname = "u949606062_equifax";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Conexión fallida: " . $conn->connect_error]));
}

// Asegurar que las consultas sean en UTF-8
$conn->set_charset("utf8");
?>
