<?php
header("Content-Type: application/json");
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $cedula = $_GET["cedula"] ?? '';

    if (!$cedula) {
        echo json_encode(["error" => "Cédula no proporcionada"]);
        exit;
    }

    $sql = "SELECT * FROM usuarios WHERE cedula = '$cedula'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode(["message" => "Usuario encontrado"]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Usuario no encontrado"]);
    }
}

$conn->close();
?>
