<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // Permitir acceso desde cualquier dominio
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'database.php';

// Verifica que la conexión no haya fallado
if ($conn->connect_error) {
    echo json_encode(["error" => "Conexión fallida: " . $conn->connect_error]);
    exit;
}

// Manejo de solicitudes
$method = $_SERVER["REQUEST_METHOD"];

switch ($method) {
    case "GET":
        $sql = "SELECT * FROM usuarios";
        $result = $conn->query($sql);

        $usuarios = [];
        while ($row = $result->fetch_assoc()) {
            $usuarios[] = $row;
        }

        echo json_encode($usuarios);
        break;

    case "POST":
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = $data["nombre"] ?? null;
        $cedula = $data["cedula"] ?? null;

        if (!$nombre || !$cedula) {
            echo json_encode(["error" => "Todos los campos son obligatorios"]);
            exit;
        }

        $checkSql = "SELECT * FROM usuarios WHERE cedula = '$cedula'";
        $checkResult = $conn->query($checkSql);

        if ($checkResult->num_rows > 0) {
            echo json_encode(["error" => "Esta cédula ya está registrada"]);
        } else {
            $sql = "INSERT INTO usuarios (cedula, nombre) VALUES ('$cedula', '$nombre')";
            if ($conn->query($sql) === TRUE) {
                echo json_encode(["message" => "Usuario agregado correctamente"]);
            } else {
                echo json_encode(["error" => "Error al agregar usuario"]);
            }
        }
        break;

    case "DELETE":
        parse_str(file_get_contents("php://input"), $_DELETE);
        $cedula = $_DELETE["cedula"] ?? null;

        if (!$cedula) {
            echo json_encode(["error" => "Cédula es obligatoria"]);
            exit;
        }

        $sql = "DELETE FROM usuarios WHERE cedula='$cedula'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "Usuario eliminado"]);
        } else {
            echo json_encode(["error" => "Error al eliminar usuario"]);
        }
        break;

    default:
        echo json_encode(["error" => "Método no permitido"]);
        break;
}

$conn->close();
?>
