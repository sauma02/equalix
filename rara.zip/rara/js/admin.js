document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("cedulas-form").addEventListener("submit", (e) => {
        e.preventDefault();
        añadirUsuario();
    });

    actualizarLista();
});

async function añadirUsuario() {
    let nombre = document.getElementById("nombre").value.trim();
    let cedula = document.getElementById("cedula").value.trim();

    if (!nombre || !cedula) {
        showAlert("Todos los campos son obligatorios", "danger");
        return;
    }

    let formData = new FormData();
    formData.append("nombre", nombre);
    formData.append("cedula", cedula);

    try {
        let response = await fetch("../php/usuarios.php", {
            method: "POST",
            body: formData
        });

        let result = await response.json();
        showAlert(result.message || result.error, result.error ? "danger" : "success");
        actualizarLista();
    } catch (error) {
        showAlert("Error al conectar con el servidor", "danger");
    }
}

async function actualizarLista() {
    let listaUsuarios = document.getElementById("lista");
    listaUsuarios.innerHTML = "";

    try {
        let response = await fetch("../php/usuarios.php");
        let usuarios = await response.json();

        usuarios.forEach((usuario) => {
            let tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${usuario.nombre}</td>
                <td>${usuario.cedula}</td>
                <td>
                    <a href="#" onclick="eliminarUsuario('${usuario.cedula}')" class="btn btn-danger btn-sm">Borrar</a>
                </td>
            `;
            listaUsuarios.appendChild(tr);
        });
    } catch (error) {
        showAlert("Error al obtener la lista de usuarios", "danger");
    }
}

async function eliminarUsuario(cedula) {
    let formData = new FormData();
    formData.append("cedula", cedula);

    try {
        let response = await fetch("../php/usuarios.php", {
            method: "DELETE",
            body: formData
        });

        let result = await response.json();
        showAlert(result.message || result.error, result.error ? "danger" : "warning");
        actualizarLista();
    } catch (error) {
        showAlert("Error al eliminar el usuario", "danger");
    }
}

function showAlert(message, className) {
    const div = document.createElement("div");
    div.className = `alert alert-${className}`;
    div.appendChild(document.createTextNode(message));

    const container = document.querySelector(".container");
    const main = document.querySelector(".main");
    container.insertBefore(div, main);

    setTimeout(() => document.querySelector(".alert").remove(), 3000);
}
